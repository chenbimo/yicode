export const appConfig = {
    // 腾讯地图 key
    qqMapKey: '',
    // 命名空间
    namespace: 'yiuni-vue3',
    // 底部栏路由
    tabbar: [
        //
        '/pages/index/index',
        '/pages/mall/index',
        '/pages/news/index',
        '/pages/tuan/index',
        '/pages/mine/index'
    ]
};
